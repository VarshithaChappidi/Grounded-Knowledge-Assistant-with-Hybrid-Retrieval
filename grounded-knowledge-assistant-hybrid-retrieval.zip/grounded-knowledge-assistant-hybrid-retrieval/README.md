# Grounded Knowledge Assistant with Hybrid Retrieval

A local-first document question-answering API that combines lexical BM25-style retrieval, TF-IDF semantic approximation, reciprocal-rank fusion, source citations, and evidence-based abstention.

> **Scope:** This repository is a reproducible engineering project/starter implementation. The included retrieval benchmark is designed to be run on your own labeled data. No benchmark scores are claimed in advance.

## What it does
- Ingests text documents with stable document IDs and chunk-level source metadata.
- Retrieves with lexical and vector-space signals, then combines rankings with reciprocal-rank fusion.
- Returns cited evidence and abstains when the best evidence score is below a configurable threshold.
- Exposes FastAPI endpoints for ingestion, search, and question answering.
- Includes a benchmark runner that reports Recall@5, reciprocal rank, answer-evidence coverage proxy, latency, and estimated token cost.
- Includes a PostgreSQL/pgvector schema for a production-oriented persistence extension. The runnable demo uses an in-memory store so it works without external services.

## Architecture
```text
Documents -> chunking -> in-memory chunk store
                         |-> lexical retrieval
Question -------------- |-> TF-IDF retrieval
                         -> reciprocal-rank fusion -> evidence threshold
                                                   -> cited answer / abstention
```

## Quick start
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000/docs`.

### Example
```bash
curl -X POST http://127.0.0.1:8000/documents \
  -H "Content-Type: application/json" \
  -d '{"documents":[{"id":"policy-1","title":"Refund policy","text":"Customers may request a refund within 30 days of purchase."}]}'

curl -X POST http://127.0.0.1:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"question":"How long do customers have to request a refund?"}'
```

The answer is extractive: it quotes the strongest retrieved sentence rather than inventing a generative answer. This makes grounding behavior testable without requiring an external LLM key.

## Benchmark
Create a JSONL file with one record per question:
```json
{"question":"How long is the refund window?","relevant_chunk_ids":["policy-1:0"]}
```
Run:
```bash
python scripts/run_benchmark.py --dataset data/sample_queries.jsonl --output reports/benchmark.json
```
The script reports Recall@5, MRR@5, mean latency, and a simple evidence-coverage proxy. For real evaluation, use a manually labeled query set and define a groundedness rubric with human review; do not treat the proxy as a substitute for answer-quality annotation.

## Configuration
- `ABSTAIN_THRESHOLD` (default `0.05`): minimum normalized fused score to return evidence.
- `CHUNK_SIZE` (default `700` characters)
- `CHUNK_OVERLAP` (default `100` characters)

## PostgreSQL / pgvector extension
`sql/schema.sql` defines a chunk table with vector storage and metadata. The demo's TF-IDF vectorizer is intentionally local and is not a substitute for a production embedding model. To use pgvector, generate fixed-dimension embeddings with a selected model and adapt the repository layer to persist/query those vectors.

## Tests
```bash
pytest -q
```

## Limitations and next steps
- TF-IDF is used as a lightweight vector-space baseline; replace with a versioned embedding model for semantic retrieval.
- The demo extracts a supporting sentence; connect a selected LLM only after adding prompt-injection defenses, source-constrained generation, and human-reviewed groundedness tests.
- The benchmark's evidence-coverage proxy is not a human groundedness score.
- Add tenant isolation, authentication, persistent storage, rate limits, and observability before exposing this service publicly.
